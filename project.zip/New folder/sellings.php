<?php include 'header.php';?>
<!DOCTYPE html>
<html>
<head>
	<title>Sell Page</title>
	<link rel="stylesheet" type="text/css" href="sellings.css">
</head>
<body>
<form action="seller_request.php" method="POST"
	<div class="container">
		<h1>Sell Page</h1>
		<div class="product-grid">
			<div class="product">
				<img src="computer.jpeg">
				<h3>Computer</h3>
				<p>Old computers and unused Computers are acceptable</p>
				<button class="sell-button">Sell Now</button>
			</div>
			<div class="product">
				<img src="ac.jpeg">
				<h3>Air Conditioner</h3>
				<p>Old AC and unused AC are acceptable</p>
				<button class="sell-button">Sell Now</button>
			</div>
			<div class="product">
				<img src="freezer.jpeg">
				<h3>Freezers</h3>
				<p>old freezers are acceptable</p>
				<button class="sell-button">Sell Now</button>
			</div>
			<div class="product">
				<img src="product3.jpg">
				<h3>Product 3</h3>
				<p>Description of Product 3</p>
				<button class="sell-button">Sell Now</button>
			</div>
			<div class="product">
				<img src="product3.jpg">
				<h3>Product 3</h3>
				<p>Description of Product 3</p>
				<button class="sell-button">Sell Now</button>
			</div>
			<div class="product">
				<img src="product3.jpg">
				<h3>Product 3</h3>
				<p>Description of Product 3</p>
				<button class="sell-button">Sell Now</button>
			</div>
			<div class="product">
				<img src="product3.jpg">
				<h3>Product 3</h3>
				<p>Description of Product 3</p>
				<button class="sell-button">Sell Now</button>
			</div>
			<div class="product">
				<img src="product3.jpg">
				<h3>Product 3</h3>
				<p>Description of Product 3</p>
				<button class="sell-button">Sell Now</button>
			</div>
			<div class="product">
				<img src="product3.jpg">
				<h3>Product 3</h3>
				<p>Description of Product 3</p>
				<button class="sell-button">Sell Now</button>
			</div>
			<div class="product">
				<img src="product3.jpg">
				<h3>Product 3</h3>
				<p>Description of Product 3</p>
				<button class="sell-button">Sell Now</button>
			</div>
			<div class="product">
				<img src="product3.jpg">
				<h3>Product 3</h3>
				<p>Description of Product 3</p>
				<button class="sell-button">Sell Now</button>
			</div>
			<div class="product">
				<img src="product3.jpg">
				<h3>Product 3</h3>
				<p>Description of Product 3</p>
				<button class="sell-button">Sell Now</button>
			</div>
			<div class="product">
				<img src="product3.jpg">
				<h3>Product 3</h3>
				<p>Description of Product 3</p>
				<button class="sell-button">Sell Now</button>
			</div>
			<div class="product">
				<img src="product3.jpg">
				<h3>Product 3</h3>
				<p>Description of Product 3</p>
				<button class="sell-button">Sell Now</button>
			</div>
			<div class="product">
				<img src="product3.jpg">
				<h3>Product 3</h3>
				<p>Description of Product 3</p>
				<button class="sell-button">Sell Now</button>
			</div>
			<div class="product">
				<img src="product3.jpg">
				<h3>Product 3</h3>
				<p>Description of Product 3</p>
				<button class="sell-button">Sell Now</button>
			</div>
			<div class="product">
				<img src="product3.jpg">
				<h3>Product 3</h3>
				<p>Description of Product 3</p>
				<button class="sell-button">Sell Now</button>
			</div>
			
			<!-- Add more products here -->
		</div>
	</div>
	</form>
	
</body>
<?php include 'footer.php';?>
</html>
