<!DOCTYPE html>
<html>
<head>
	<title>Sell Page</title>
	<link rel="stylesheet" type="text/css" href="header.css">
</head>
<body>
<header>
  <nav>
    <ul>
      <li><a href="status.php">Status</a></li>
      <li><a href="home_page.php">About Us</a></li>
	  <li><a href="sellings.php">Sell</a></li>
	  <li><a href="login.php">Logout</a></li>
    </ul>
  </nav>
</header>
</body>
</html>
